from django.urls import path
from .views import *

urlpatterns = [

    path('', Home, name='home'),
    path('shop/', Shop, name='shop'),
    path('checkout/', Checkout, name='checkout'),
    path('detail/<int:userId>/', Detail, name='detail'),
    path('cart/', Cart, name='cart'),


]