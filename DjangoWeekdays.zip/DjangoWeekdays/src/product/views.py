from django.http import HttpResponse
from django.shortcuts import render

from .models import  Product

def Home(request):
    phones = Product.objects.raw("SELECT * FROM product_product WHERE category =  %s" ,["phone"])
    laptop = Product.objects.raw("SELECT * FROM product_product WHERE category =  %s", ["laptop"])
    data = Product.objects.all()

    for data1 in laptop:
        print(data1)



    return render(request,"product/index.html",{"phone":phones,"laptop":laptop,"all":data})


def Shop(request):
  data =    Product.objects.all()
  return render(request,"product/shop.html",{"bass":data})

# def Contact(request):
#   data =    Product.objects.all()
#   return render(request,"product/contact.html",{"bass":data})

def Detail(request,userId):
  data =    Product.objects.get(id=userId)
  return render(request,"product/detail.html",{"detail":data})

def Checkout(request):
  data =    Product.objects.all()
  return render(request,"product/checkout.html",{"bass":data})

def Cart(request):
  data =    Product.objects.all()
  return render(request,"product/cart.html",{"bass":data})