from django.shortcuts import render
from .models import Cart


# Create your views here.

def CartList(request):
    cart = Cart.objects.all()
    return render(request,"cart/cart.html",{"cart":cart})


def AddCartList(request,code):
    cart = Cart.objects.all()
    return render(request,"cart/cart.html",{"cart":cart})

def EditCartList(request,code):
    cart = Cart.objects.all()
    return render(request,"cart/cart.html",{"cart":cart})

def DeleteCartList(request,code):
    cart = Cart.objects.all()
    return render(request,"cart/cart.html",{"cart":cart})
