from django.urls import path

from .views import *

urlpatterns = [
    path('CartList/',CartList,name ="CartList"),
    path('AddCartList/<int:code>', AddCartList, name="AddCartList"),
    path('EditCartList/<int:code>', EditCartList, name="EditCartList"),
    path('DeleteCartList/<int:code>', DeleteCartList, name="DeleteCartList")
]