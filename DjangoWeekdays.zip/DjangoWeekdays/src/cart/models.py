# from django.contrib.auth.models import User
from django.contrib.auth.models import User
from django.db import models
from product.models import Product


# Create your models here.

class Cart(models.Model):
    user = models.ForeignKey(User, null=True ,on_delete=models.CASCADE)
    product = models.ForeignKey(Product,null=True, on_delete=models.CASCADE)
    price = models.FloatField()
    quantity = models.IntegerField()
    code = models.CharField(max_length=255)


    def __str__(self):
        return  self.product

