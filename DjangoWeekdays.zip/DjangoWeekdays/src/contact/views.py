from django.shortcuts import render
from .forms import ContactForm
from .models import Contact


# Create your views here.

def contact(request):
    message = ""
    data = Contact.objects.all()
    form = ContactForm
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            message = "Message sent successfully"
            request.POST = ""
        else:
            message = "Message not sent"
    return render(request, "contact/contact.html", {"form": form,"message":message})
