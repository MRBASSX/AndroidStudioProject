from django import forms

from .models import Contact


class ContactForm(forms.ModelForm):

    class Meta:
        # specify model to be used
        model = Contact

        # specify fields to be used
        exclude = ["id"]
        # add Bootstrap

