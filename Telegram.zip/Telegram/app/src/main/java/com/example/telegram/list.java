package com.example.telegram;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class list extends AppCompatActivity {

    SearchView searchView;
    ListView listView;
    ArrayList<CustomModel> arrayList;

    CustomAdapter  customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        listView = findViewById(R.id.list_view);
        searchView = findViewById(R.id.searchView);

            mainFun();


    }

    private void mainFun() {

        arrayList = new ArrayList<CustomModel>();
        arrayList.add(new CustomModel(R.drawable.cover,"apple".toLowerCase(),5000.56));
        arrayList.add(new CustomModel(R.drawable.virus1,"orange".toLowerCase(),5000.56));
        arrayList.add(new CustomModel(R.drawable.fire,"pawpaw".toLowerCase(),5000.56));
        arrayList.add(new CustomModel(R.drawable.cover,"pineapple".toLowerCase(),5000.56));
        arrayList.add(new CustomModel(R.drawable.virus1,"lemon".toLowerCase(),5000.56));
        arrayList.add(new CustomModel(R.drawable.fire,"banana".toLowerCase(),5000.56));

        customAdapter = new CustomAdapter(this,R.layout.customlayout, arrayList);
        SearchClickListener();
        listView.setAdapter(customAdapter);

    }



    private void filterList(String text) {

        ArrayList filteredList = new ArrayList<CustomModel>();

        for (CustomModel  Sdata: arrayList) {

            if (Sdata.getName().contains(text)){

                filteredList.add(Sdata);

            };

        }

        if (!filteredList.isEmpty()){

            CustomAdapter  customAdapter2 = new CustomAdapter(this,R.layout.customlayout, filteredList);

            listView.setAdapter(customAdapter2);
            customAdapter2.notifyDataSetChanged();


        }else {

            Toast.makeText(this, "No Record Found", Toast.LENGTH_SHORT).show();
            CustomAdapter  customAdapter2 = new CustomAdapter(this,R.layout.customlayout, filteredList);

            listView.setAdapter(customAdapter2);
            customAdapter2.notifyDataSetChanged();
        }
    }


    private void SearchClickListener(){

//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//            }
//        });


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                filterList(query.toLowerCase(Locale.ROOT));
                customAdapter.notifyDataSetChanged();

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                filterList(newText.toLowerCase(Locale.ROOT));
                customAdapter.notifyDataSetChanged();
                return false;
            }
        });
    }


}