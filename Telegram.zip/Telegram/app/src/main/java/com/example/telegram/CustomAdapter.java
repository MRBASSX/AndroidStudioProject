package com.example.telegram;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends ArrayAdapter<CustomModel> {
    Context Rcontext;
    int Rresource;
    LayoutInflater object;

    public CustomAdapter(@NonNull Context context, int resource, @NonNull ArrayList<CustomModel> objects) {
        super(context, resource, objects);
        this.Rcontext = context;
        this.Rresource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        object = LayoutInflater.from(Rcontext);

        convertView  = object.inflate(Rresource,parent,false);

        ImageView image = convertView.findViewById(R.id.CustomImage);
        TextView name = convertView.findViewById(R.id.CustomName);
        TextView price = convertView.findViewById(R.id.CustomPrice);

        image.setImageResource(getItem(position).getImage());
        name.setText(getItem(position).getName());
        price.setText(String.valueOf(getItem(position).getPrice()));

        return convertView;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }
}
