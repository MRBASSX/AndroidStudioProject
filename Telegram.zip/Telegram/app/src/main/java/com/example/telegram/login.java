package com.example.telegram;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class login extends AppCompatActivity {


    EditText username , password ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.username2);
        password = findViewById(R.id.password2);



        
        
    }
    
    
    public void Register(View V){

      Intent intent = new Intent(login.this,register.class);
      startActivity(intent);

    }
    
    public void Login(View V){
        String Username = username.getText().toString();
        String Password = password.getText().toString();

//        ArrayList  object = new ArrayList<String>();
//        object.add("Alfred");
//        object.add("K.O.K");
//        object.add("Abass");
//
//
//        String Data[] = { "Alfred" ,"K.O.K", "Abass" };

        if(Username.isEmpty() || Password.isEmpty()){

            Toast.makeText(this, "All field is required", Toast.LENGTH_SHORT).show();

        }else {

            if((Username.equals("Abass@gmail.com") || Username.equals("Abass")) && Password.equals("123456789")){

                Intent  intent = new Intent(login.this, list.class);
                intent.putExtra("user",Username);
                intent.putExtra("pass",Password);
//                intent.putExtra("key",object);
                startActivity(intent);
                Toast.makeText(this, "Welcome , " + Username, Toast.LENGTH_SHORT).show();

            }else{

                Toast.makeText(this, "Wrong Credential Try Again", Toast.LENGTH_SHORT).show();
            }

        }

    }
    

    
}