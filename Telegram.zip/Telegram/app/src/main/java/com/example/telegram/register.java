package com.example.telegram;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class register extends AppCompatActivity {
  EditText username,email,password,confirmed_password;
//  ConstraintLayout register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


//        register = findViewById(R.id.register);
//
//        register.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Toast.makeText(register.this, "You have successfull  Registered", Toast.LENGTH_SHORT).show();
//
//
//            }
//        });

    }




    public  void Registed(View v){

        username = findViewById(R.id.username);
        String Username = username.getText().toString();

        email = findViewById(R.id.email);
        String Email = email.getText().toString();

        password = findViewById(R.id.password);
        String Password = password.getText().toString();

        confirmed_password = findViewById(R.id.cofirm_password);
        String Confirm_password = confirmed_password.getText().toString();


        if(Username.isEmpty() && Email.isEmpty() && Password.isEmpty() && Confirm_password.isEmpty() ){

            Toast.makeText(register.this, "All Field Is Required", Toast.LENGTH_SHORT).show();

        }else if ( !Email.endsWith(".com") || !Email.contains("@") ){

            Toast.makeText(register.this, "Please Enter a valid Email", Toast.LENGTH_SHORT).show();

        }else if (!Confirm_password.equals(Password) ){

        Toast.makeText(register.this, "Password do not match", Toast.LENGTH_SHORT).show();

    }else{
            Intent intent = new Intent(register.this, list.class);
            startActivity(intent);
            Toast.makeText(register.this, "You have successfully Registered ,Hi " + Username, Toast.LENGTH_SHORT).show();

        }

    }


    public void Login(View V){

        Intent intent = new Intent(register.this, login.class);
        startActivity(intent);
    }
}