package com.example.telegram;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class home extends AppCompatActivity {

    TextView welcome ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        welcome = findViewById(R.id.welcome_name);

        Intent intent = getIntent();

       String userData =  intent.getStringExtra("user");
       String passData = intent.getStringExtra("pass");
//       ArrayList  passDatas = intent.getStringArrayListExtra("key");
        welcome.setText(userData);

        Toast.makeText(this, userData + " " + passData, Toast.LENGTH_SHORT).show();

    }

    public void logout(View V){

        Intent login = new Intent(home.this, login.class);
        startActivity(login);
        Toast.makeText(this, "You have Logout", Toast.LENGTH_SHORT).show();

    }
}