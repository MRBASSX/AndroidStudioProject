from django.shortcuts import render

from .forms import ContactForm
from .models import Contact


# Create your views here.

def contact(request):
    message = ""
    data = Contact.objects.all()
    forms = ContactForm
    print(request.POST)
    if request.method == "POST":
        forms = ContactForm(request.POST)
        if forms.is_valid():
            forms.save()
            request.POST =""
            message = "Message sent Successfully"
        else:
             message = "Message not sent"

    return render(request,"contact/contact.html", {"food": data,"form":forms,'message': message})
    # print(data)