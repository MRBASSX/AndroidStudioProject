from django.shortcuts import render

from .models import Product

from .forms import ProductForm


# Create your views here.



def home(request):
    data = Product.objects.all()
    form  = ProductForm
    return render(request,"product/index.html", {"food": data, 'forms':form})
    # print(data)


def show(request,id):
    data = Product.objects.get(id = id);
    return render(request,"product/detail.html", {"detail": data})
    # print(data)



def shop(request):
    data = Product.objects.all()
    return render(request,"product/shop.html", {"food": data})
    # print(data)

def cart(request):
    data = Product.objects.all()
    return render(request,"product/cart.html", {"food": data})
    # print(data)

def checkout(request):
    data = Product.objects.all()
    return render(request,"product/checkout.html", {"food": data})
    # print(data)