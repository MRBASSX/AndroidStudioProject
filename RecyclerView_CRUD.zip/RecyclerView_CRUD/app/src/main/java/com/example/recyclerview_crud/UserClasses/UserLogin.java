package com.example.recyclerview_crud.UserClasses;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.recyclerview_crud.AdminClasses.FormUploadData;
import com.example.recyclerview_crud.AdminClasses.MainActivity;
import com.example.recyclerview_crud.R;

public class UserLogin extends AppCompatActivity {

    EditText email,pass;

    private String mail ,password;

    private  String  databaseemail;
    private String  databasepass;
    private String databasename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);



    }


    public void SaveData(View view){

        try {
            email  = findViewById(R.id.user_email);
            mail = email.getText().toString();

            pass = findViewById(R.id.user_pass);
            password = pass.getText().toString();
            if (mail.isEmpty() || password.isEmpty()){
                Toast.makeText(this, "All Field is Required", Toast.LENGTH_SHORT).show();
            } else {
                Show(mail);
            }


        }catch (Exception e){

            Toast.makeText(this, "Invalide Email or Password", Toast.LENGTH_SHORT).show();

        }

    }

    public void  Show(String Email){

        try {
            UserDatabaseClass dbHelper = new UserDatabaseClass(UserLogin.this);


            SQLiteDatabase db = dbHelper.getReadableDatabase();


            String[] projection = {
                    BaseColumns._ID,
                    UserTable.UserEntry.COLUMN_NAME_NAME,
                    UserTable.UserEntry.COLUMN_NAME_PASS,
                    UserTable.UserEntry.COLUMN_NAME_IMAGE,
                    UserTable.UserEntry.COLUMN_NAME_EMAIL,
            };

            // Filter results WHERE "title" = 'My Title'

            String selection = UserTable.UserEntry.COLUMN_NAME_EMAIL + " = ?";
            String[] selectionArgs = {Email};





            Cursor cursor = db.query(
                    UserTable.UserEntry.TABLE_NAME,   // The table to query
                    projection,             // The array of columns to return (pass null to get all)
                    selection,              // The columns for the WHERE clause
                    selectionArgs,          // The values for the WHERE clause
                    null,                   // don't group the rows
                    null,                   // don't filter by row groups
                    null               // The sort order
            );


            while(cursor.moveToNext()) {

               databaseemail =  cursor.getString(4);
               databasepass =  cursor.getString(2);
                 databasename = cursor.getString(1);




            }

            cursor.close();



        }catch (Exception e){


            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        }


        if ("Admin@gmail.com".equals(String.valueOf(mail)) &&  "admin".equals(String.valueOf(password))){

            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("name",databasename);
            startActivity(intent);


        }
        else  if (databaseemail.equals(String.valueOf(mail)) &&  databasepass.equals(String.valueOf(password))){

            Intent intent = new Intent(this, FormUploadData.class);
            intent.putExtra("name",databasename);
            startActivity(intent);

        }else {

            Toast.makeText(this, "Invalide Email or Password", Toast.LENGTH_SHORT).show();

        }


    }

    public void Register(View view){

        Intent intent = new Intent(this,UserRegistration.class);
        startActivity(intent);

    }

}

