package com.example.recyclerview_crud.AdminClasses;

import android.provider.BaseColumns;

public class ProductTable {

    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private ProductTable() {}

    /* Inner class that defines the table contents */
    public static class ProductEntry implements BaseColumns {
        public static final String TABLE_NAME = "component";
        public static final String COLUMN_NAME_IMAGE = "image";
        public static final String COLUMN_NAME_NAME = "name";
        public static final String COLUMN_NAME_DESKS = "desks";
        public static final String COLUMN_NAME_TITLE = "title";



    }
}