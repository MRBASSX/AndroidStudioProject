package com.example.recyclerview_crud.UserClasses;




import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.recyclerview_crud.AdminClasses.CustomData;
import com.example.recyclerview_crud.AdminClasses.MainActivity;

import com.example.recyclerview_crud.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;


public class UserRegistration extends AppCompatActivity {


    EditText title,expla,name;
    ImageView product_image;
    TextView count;

    byte[] imagebytes;
    Bitmap imageToStore;
    String inputtitle;
    String inputdesc;
    String inputname;

    String email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);
        getSupportActionBar().hide();
        count = findViewById(R.id.Usercount);
        product_image =findViewById(R.id.Pimage);
        DefaultImage();



    }




    public void DefaultImage(){

        String imagePath = "android.resource://"+getPackageName()+"/"+R.drawable.draw2;
        Uri uri = Uri.parse(imagePath);

        try {
            imageToStore = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
//            product_image.setImageBitmap(imageToStore);
        } catch (IOException e) {

            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }



    }


    public void AddData(CustomData object){

        UserDatabaseClass dbHelper = new UserDatabaseClass(UserRegistration.this);
        // Gets the data repository in write mode
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        try {
            ByteArrayOutputStream objectStream = new ByteArrayOutputStream();
            object.getImage().compress(Bitmap.CompressFormat.JPEG,100,objectStream);
            imagebytes = objectStream.toByteArray();
//            Toast.makeText(this, "Works " + imagebytes, Toast.LENGTH_SHORT).show();
        }catch (Exception e){

            Toast.makeText(this, imagebytes.toString(), Toast.LENGTH_SHORT).show();
        }


// Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put(UserTable.UserEntry.COLUMN_NAME_NAME, object.getName());
        values.put(UserTable.UserEntry.COLUMN_NAME_PASS, object.getDes());
        values.put(UserTable.UserEntry.COLUMN_NAME_EMAIL, object.getTitle());
        values.put(UserTable.UserEntry.COLUMN_NAME_IMAGE, imagebytes);

// Insert the new row, returning the primary key value of the new row
        long newRowId = db.insert(UserTable.UserEntry.TABLE_NAME, null, values);
        count.setText(String.valueOf((newRowId)));
    }


    public void  SaveData(View view) {

        title = findViewById(R.id.user_email);
        inputtitle = title.getText().toString();

        expla = findViewById(R.id.user_pass);
        inputdesc = expla.getText().toString();

        name= findViewById(R.id.ProductName);
        inputname = name.getText().toString();

        if (inputtitle.isEmpty() || inputdesc.isEmpty() || inputname.isEmpty() || imageToStore==null  ){

            Toast.makeText(this, "All Field Is Required", Toast.LENGTH_SHORT).show();

        }else{

             String mail = String.valueOf(Show(inputtitle));

            if (mail.equals(String.valueOf(inputtitle))) {
                Toast.makeText(this, "Email already Exist " +mail , Toast.LENGTH_SHORT).show();


            }else {

                AddData(new CustomData(inputname,inputtitle,inputdesc,imageToStore));
                Toast.makeText(this, "Registration Successfully", Toast.LENGTH_SHORT).show();

            }
        }
    }

    public  void ShowData(View view){

        Intent intent = new Intent(UserRegistration.this, MainActivity.class);
        startActivity(intent);
    }



    public String  Show(String Email){

        try {
            UserDatabaseClass dbHelper = new UserDatabaseClass(UserRegistration.this);


            SQLiteDatabase db = dbHelper.getReadableDatabase();


            String[] projection = {
                    BaseColumns._ID,
                    UserTable.UserEntry.COLUMN_NAME_NAME,
                    UserTable.UserEntry.COLUMN_NAME_PASS,
                    UserTable.UserEntry.COLUMN_NAME_IMAGE,
                    UserTable.UserEntry.COLUMN_NAME_EMAIL,
            };

            // Filter results WHERE "title" = 'My Title'

            String selection = UserTable.UserEntry.COLUMN_NAME_EMAIL + " = ?";
            String[] selectionArgs = {Email};



// How you want the results sorted in the resulting Cursor
//            String sortOrder =
//                    UserTable.UserEntry.COLUMN_NAME_NAME  + " DESC";

            Cursor cursor = db.query(
                    UserTable.UserEntry.TABLE_NAME,   // The table to query
                    projection,             // The array of columns to return (pass null to get all)
                    selection,              // The columns for the WHERE clause
                    selectionArgs,          // The values for the WHERE clause
                    null,                   // don't group the rows
                    null,                   // don't filter by row groups
                    null               // The sort order
            );


            while(cursor.moveToNext()) {

                email =  cursor.getString(4);




            }
//            Toast.makeText(this, email, Toast.LENGTH_SHORT).show();
            cursor.close();



        }catch (Exception e){


            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        }


        return email;
    }



    public void Login(View view){

        Intent intent = new Intent(this,UserLogin.class);
        startActivity(intent);

    }

}