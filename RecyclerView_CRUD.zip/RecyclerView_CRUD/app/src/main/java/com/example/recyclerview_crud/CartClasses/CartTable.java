package com.example.recyclerview_crud.CartClasses;

import android.provider.BaseColumns;

public class CartTable {

    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private CartTable() {}

    /* Inner class that defines the table contents */
    public static class CartEntry implements BaseColumns {
        public static final String TABLE_NAME = "cart";
        public static final String COLUMN_NAME_USER= "user";
        public static final String COLUMN_NAME_CODE= "code";
        public static final String COLUMN_NAME_QUANTITY = "quantity";
        public static final String COLUMN_NAME_TIME = "time";




    }
}
