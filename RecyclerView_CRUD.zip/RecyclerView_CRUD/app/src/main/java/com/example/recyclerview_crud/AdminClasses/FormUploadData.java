package com.example.recyclerview_crud.AdminClasses;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import com.example.recyclerview_crud.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class FormUploadData extends AppCompatActivity {

    EditText title,expla,name;
    ImageView product_image;
    TextView count;
    ActivityResultLauncher<Intent> GallaryImage;
    byte[] imagebytes;
    Bitmap  imageToStore;
    String inputtitle;
    String inputdesc;
    String inputname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_upload_data);
        getSupportActionBar().hide();
        count = findViewById(R.id.Usercount);
        product_image =findViewById(R.id.Pimage);

        storeGalaryImage();

    }

    public void  UploadImage(View view){
        getGallaryImage();

    }

    public  void  getGallaryImage(){
        Intent intent =  new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        GallaryImage.launch(intent);
    }

    public  void storeGalaryImage(){

        GallaryImage = registerForActivityResult(new
                        ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {




                        try {
                            Uri uriimage = result.getData().getData();
                            imageToStore = MediaStore.Images.Media.getBitmap(getContentResolver(),uriimage);
                            product_image.setImageBitmap(imageToStore);

                        } catch (IOException e) {

                            Toast.makeText(FormUploadData.this, "Error Uploading", Toast.LENGTH_LONG).show();
                        }



                    }
                });
    }


    public void AddData(CustomData object){

        MainDatabase dbHelper = new MainDatabase(FormUploadData.this);
        // Gets the data repository in write mode
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        try {
            ByteArrayOutputStream objectStream = new ByteArrayOutputStream();
            object.getImage().compress(Bitmap.CompressFormat.JPEG,100,objectStream);
            imagebytes = objectStream.toByteArray();
            Toast.makeText(this, "Works " + imagebytes, Toast.LENGTH_SHORT).show();
        }catch (Exception e){

            Toast.makeText(this, imagebytes.toString(), Toast.LENGTH_SHORT).show();
        }


// Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put(ProductTable.ProductEntry.COLUMN_NAME_NAME, object.getName());
        values.put(ProductTable.ProductEntry.COLUMN_NAME_DESKS, object.getDes());
        values.put(ProductTable.ProductEntry.COLUMN_NAME_TITLE, object.getTitle());
        values.put(ProductTable.ProductEntry.COLUMN_NAME_IMAGE, imagebytes);

// Insert the new row, returning the primary key value of the new row
        long newRowId = db.insert(ProductTable.ProductEntry.TABLE_NAME, null, values);
        count.setText(String.valueOf((newRowId)));
    }


    public void  SaveData(View view) {

        title = findViewById(R.id.user_email);
        inputtitle = title.getText().toString();

        expla = findViewById(R.id.user_pass);
        inputdesc = expla.getText().toString();

        name= findViewById(R.id.ProductName);
        inputname = name.getText().toString();

        if (inputtitle.isEmpty() || inputdesc.isEmpty() || inputname.isEmpty() || imageToStore==null  ){

            Toast.makeText(this, "All Field Is Required", Toast.LENGTH_SHORT).show();

        }else{

            AddData(new CustomData(inputname,inputtitle,inputdesc,imageToStore));

        }
    }

    public  void ShowData(View view){

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}