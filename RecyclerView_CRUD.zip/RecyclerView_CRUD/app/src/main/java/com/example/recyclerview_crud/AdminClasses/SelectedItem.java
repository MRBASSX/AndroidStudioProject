package com.example.recyclerview_crud.AdminClasses;

import com.example.recyclerview_crud.AdminClasses.CustomData;

public interface SelectedItem {

    public void onitemClick(CustomData customData);
}
