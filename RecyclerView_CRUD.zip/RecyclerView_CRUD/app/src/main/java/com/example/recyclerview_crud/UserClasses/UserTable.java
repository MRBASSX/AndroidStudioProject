package com.example.recyclerview_crud.UserClasses;

import android.provider.BaseColumns;

public class UserTable {

    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private UserTable() {}

    /* Inner class that defines the table contents */
    public static class UserEntry implements BaseColumns {
        public static final String TABLE_NAME = "user";
        public static final String COLUMN_NAME_IMAGE = "image";
        public static final String COLUMN_NAME_NAME = "name";
        public static final String COLUMN_NAME_PASS = "pass";
        public static final String COLUMN_NAME_EMAIL = "email";



    }
}
