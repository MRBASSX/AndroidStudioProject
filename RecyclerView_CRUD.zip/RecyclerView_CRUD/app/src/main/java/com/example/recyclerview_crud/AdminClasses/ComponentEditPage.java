package com.example.recyclerview_crud.AdminClasses;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.recyclerview_crud.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ComponentEditPage extends AppCompatActivity {

    EditText title,desc,name;
    ImageView product_image;

    TextView count;
    ActivityResultLauncher<Intent> GallaryImage;
    Bitmap bitmap;

    byte[] image;
    byte[] imagebytes;
    Bitmap imageToStore;
    String inputtitle;
    String inputdesc;
    String inputname;

    List<CustomData> itemIds;
    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_component_edit_page);
        getSupportActionBar().hide();
        count = findViewById(R.id.Usercount);
        product_image =findViewById(R.id.Pimage);
        title = findViewById(R.id.user_email);
        inputtitle = title.getText().toString();

        desc = findViewById(R.id.user_pass);
        inputdesc = desc.getText().toString();

        name= findViewById(R.id.ProductName);
        inputname = name.getText().toString();
        storeGalaryImage();
        Intent intent = getIntent();
         String Editme =  intent.getStringExtra("component");
         ShowData(Editme);



    }

    public void  UploadImage(View view){
        getGallaryImage();

    }

    public  void  getGallaryImage(){
        Intent intent =  new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        GallaryImage.launch(intent);
    }

    public  void storeGalaryImage(){

        GallaryImage = registerForActivityResult(new
                        ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {




                        try {
                            Uri uriimage = result.getData().getData();
                            imageToStore = MediaStore.Images.Media.getBitmap(getContentResolver(),uriimage);
                            product_image.setImageBitmap(imageToStore);
                        } catch (IOException e) {

                            Toast.makeText(ComponentEditPage.this, "Error Uploading", Toast.LENGTH_LONG).show();
                        }



                    }
                });
    }


    public void DataEdited(View v){
        builder = new AlertDialog.Builder(this);
        builder.setTitle("Alert!!!!")
                .setMessage("Do you want to Save Changes ?")
                .setCancelable(true)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        title = findViewById(R.id.user_email);
                        inputtitle = title.getText().toString();

                        desc = findViewById(R.id.user_pass);
                        inputdesc = desc.getText().toString();

                        name= findViewById(R.id.ProductName);
                        inputname = name.getText().toString();

                        if (inputtitle.isEmpty() || inputdesc.isEmpty() || inputname.isEmpty() || imageToStore==null  ){

                            Toast.makeText(ComponentEditPage.this, "All Field Is Required", Toast.LENGTH_SHORT).show();

                        }else{

                            DataEditedS(new CustomData(inputname,inputtitle, inputdesc,imageToStore));
//                            Intent grap = getIntent();
//                            String Editme =  grap.getStringExtra("component");
                            Intent intent = new Intent(ComponentEditPage.this, ComponentDetailPage.class);
                            intent.putExtra("component",inputname);
                            startActivity(intent);
                        }

                        }





                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        dialogInterface.cancel();
                    }
                })
                .show();



    }

    public void DeleteMe(View v) {




    }


    public  void DataEditedS(CustomData object){

        Intent intent = getIntent();
        String Editme =  intent.getStringExtra("component");

        MainDatabase dbHelper = new MainDatabase(ComponentEditPage.this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        try {
            ByteArrayOutputStream objectStream = new ByteArrayOutputStream();
            object.getImage().compress(Bitmap.CompressFormat.JPEG,100,objectStream);
            imagebytes = objectStream.toByteArray();
            Toast.makeText(this, "Works " + imagebytes, Toast.LENGTH_SHORT).show();
        }catch (Exception e){

            Toast.makeText(this, imagebytes.toString(), Toast.LENGTH_SHORT).show();
        }

// New value for one column
        ContentValues values = new ContentValues();
        values.put(ProductTable.ProductEntry.COLUMN_NAME_NAME, object.getName());
        values.put(ProductTable.ProductEntry.COLUMN_NAME_DESKS, object.getDes());
        values.put(ProductTable.ProductEntry.COLUMN_NAME_TITLE, object.getTitle());
        values.put(ProductTable.ProductEntry.COLUMN_NAME_IMAGE, imagebytes);

// Which row to update, based on the title
        String selection = ProductTable.ProductEntry.COLUMN_NAME_NAME + " LIKE ?";
        String[] selectionArgs = { Editme };

        int count = db.update(
                ProductTable.ProductEntry.TABLE_NAME,
                values,
                selection,
                selectionArgs);
        Toast.makeText(this, Editme, Toast.LENGTH_SHORT).show();

    }


    public void  ShowData(String Electri){

        try {
            MainDatabase dbHelper = new MainDatabase(ComponentEditPage.this);


            SQLiteDatabase db = dbHelper.getReadableDatabase();


            String[] projection = {
                    BaseColumns._ID,
                    ProductTable.ProductEntry.COLUMN_NAME_NAME,
                    ProductTable.ProductEntry.COLUMN_NAME_TITLE,
                    ProductTable.ProductEntry.COLUMN_NAME_IMAGE,
                    ProductTable.ProductEntry.COLUMN_NAME_DESKS,
            };

            // Filter results WHERE "title" = 'My Title'

            String selection = ProductTable.ProductEntry.COLUMN_NAME_NAME + " = ?";
            String[] selectionArgs = {Electri};



// How you want the results sorted in the resulting Cursor
            String sortOrder =
                    ProductTable.ProductEntry.COLUMN_NAME_TITLE  + " DESC";

            Cursor cursor = db.query(
                    ProductTable.ProductEntry.TABLE_NAME,   // The table to query
                    projection,             // The array of columns to return (pass null to get all)
                    selection,              // The columns for the WHERE clause
                    selectionArgs,          // The values for the WHERE clause
                    null,                   // don't group the rows
                    null,                   // don't filter by row groups
                    sortOrder              // The sort order
            );

            itemIds = new ArrayList<>();
            while(cursor.moveToNext()) {
                String Name =  cursor.getString(1);
                String Title =  cursor.getString(2);
                String Desc =  cursor.getString(4);
                image = cursor.getBlob(3);
                bitmap = BitmapFactory.decodeByteArray(image,0,image.length);
                name.setText(Name);
                desc.setText(Desc);
                title.setText(Title);
                product_image.setImageBitmap(bitmap);
                itemIds.add(new CustomData(Name,Title,Desc,bitmap));

            }

            cursor.close();

            if (itemIds.isEmpty()){
                Toast.makeText(this, "No Record Found ", Toast.LENGTH_SHORT).show();

            }
        }catch (Exception e){

            Toast.makeText(ComponentEditPage.this, e.toString(), Toast.LENGTH_LONG).show();




        }



    }


    public  void ShowData(View view){

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}