package com.example.recyclerview_crud.AdminClasses;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.recyclerview_crud.R;

import java.util.ArrayList;
import java.util.List;

public class ComponentDetailPage extends AppCompatActivity  {


    List<CustomData> itemIds;
    TextView name,title;
    ImageView image1;

    Bitmap bitmap;

    byte[] image;

    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_component_detail_page);
        name = findViewById(R.id.Name);
        title = findViewById(R.id.Title);
        image1 = findViewById(R.id.Image);
        image1.setImageResource(R.drawable.draw2);

        Intent intent = getIntent();
        String component = intent.getStringExtra("component");
        ShowData(component);



    }


    public void  ShowData(String Electri ){

        try {
            MainDatabase dbHelper = new MainDatabase(ComponentDetailPage.this);


            SQLiteDatabase db = dbHelper.getReadableDatabase();


            String[] projection = {
                    BaseColumns._ID,
                    ProductTable.ProductEntry.COLUMN_NAME_NAME,
                    ProductTable.ProductEntry.COLUMN_NAME_TITLE,
                    ProductTable.ProductEntry.COLUMN_NAME_IMAGE,
                    ProductTable.ProductEntry.COLUMN_NAME_DESKS,
            };

            // Filter results WHERE "title" = 'My Title'

            String selection = ProductTable.ProductEntry.COLUMN_NAME_NAME + " = ?";
            String[] selectionArgs = {Electri};



// How you want the results sorted in the resulting Cursor
            String sortOrder =
                    ProductTable.ProductEntry.COLUMN_NAME_TITLE  + " DESC";

            Cursor cursor = db.query(
                    ProductTable.ProductEntry.TABLE_NAME,   // The table to query
                    projection,             // The array of columns to return (pass null to get all)
                    selection,              // The columns for the WHERE clause
                    selectionArgs,          // The values for the WHERE clause
                    null,                   // don't group the rows
                    null,                   // don't filter by row groups
                    sortOrder               // The sort order
            );

            itemIds = new ArrayList<>();
            while(cursor.moveToNext()) {
                String Name =  cursor.getString(1);
                String Desc =  cursor.getString(2);
                String Title =  cursor.getString(4);
                Toast.makeText(this, Desc, Toast.LENGTH_SHORT).show();
                image = cursor.getBlob(3);
                bitmap = BitmapFactory.decodeByteArray(image,0,image.length);
                name.setText(Name);
                title.setText(Title);
                image1.setImageBitmap(bitmap);
                itemIds.add(new CustomData(Name,Title,Desc,bitmap));


            }

            cursor.close();

            if (itemIds.isEmpty()){

                Toast.makeText(this, "No Record Found ", Toast.LENGTH_SHORT).show();


            }

        }catch (Exception e){



            Toast.makeText(ComponentDetailPage.this, e.toString(), Toast.LENGTH_LONG).show();




        }

    }


    public void DeleteMe(View v) {

        builder = new AlertDialog.Builder(this);
        builder.setTitle("Alert!!!!")
                .setMessage("Do you want to delete Component ?")
                .setCancelable(true)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        DeleteMe2();
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        dialogInterface.cancel();
                    }
                })
                .show();





    }

    public  void DeleteMe2(){
        Intent intent = getIntent();
        final String ItemDeleted = intent.getStringExtra("component");
        MainDatabase dbHelper = new MainDatabase(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        // Define 'where' part of query.
        String selection = ProductTable.ProductEntry.COLUMN_NAME_NAME + " LIKE ?";
        // Specify arguments in placeholder order.
        String[] selectionArgs = { ItemDeleted };
        // Issue SQL statement.
        int deletedRows = db.delete(ProductTable.ProductEntry.TABLE_NAME, selection, selectionArgs);
        Toast.makeText(this, "Component Deleted " + deletedRows, Toast.LENGTH_SHORT).show();
        Intent intents = new Intent(this, MainActivity.class);
        startActivity(intents);
    }


    public void EditMe(View v) {
        Intent EditIntent = getIntent();
        final String EditCom = EditIntent.getStringExtra("component");
        Intent intent = new Intent( this, ComponentEditPage.class);
        intent.putExtra("component",EditCom);
        startActivity(intent);
        Toast.makeText(this, EditCom, Toast.LENGTH_SHORT).show();
    }

    public void Home(View v) {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }


}


