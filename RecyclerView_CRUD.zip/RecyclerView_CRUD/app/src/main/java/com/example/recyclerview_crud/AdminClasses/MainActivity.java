package com.example.recyclerview_crud.AdminClasses;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.view.View;

import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.recyclerview_crud.R;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements SelectedItem {

     RecyclerView recycler;

     SearchView searchView;

     List<CustomData> itemIds;

    byte[] image;
//    ImageView imageV;

    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycler = (RecyclerView) findViewById(R.id.mycycler2);

        searchView = (SearchView) findViewById(R.id.mysearch2);

        recycler.setLayoutManager(new GridLayoutManager(this,2));
        recycler.setHasFixedSize(true);
        ShowDataAll();
        SearchQuery();
        ToListenRecycler();









    }



    public void SearchAll(View v){

        try {
            ShowDataAll();
        }catch (Exception e){

            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }

    }

    private void filterList(String text) {

        List<CustomData> filteredList = new ArrayList<>();

        for (CustomData Sdata : itemIds) {

            if (Sdata.getName().contains(text)){

                filteredList.add(Sdata);

            };

        }

        if (filteredList.isEmpty()){

            Toast.makeText(this, "That All", Toast.LENGTH_SHORT).show();
        }else {
            CustomAdapter myadapter2 = new CustomAdapter(filteredList,this,this);

            recycler.setAdapter(myadapter2);

        }
    }

    public  void Mybutton(View view){

        Toast.makeText(MainActivity.this, "Welcome", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, FormUploadData.class);
        startActivity(intent);

    }

    public  void  ShowDataAll(){

        try {
            MainDatabase dbHelper = new MainDatabase(MainActivity.this);


            SQLiteDatabase db = dbHelper.getReadableDatabase();




            Cursor cursor = db.rawQuery( "select * from component",null);


             itemIds = new ArrayList<>();
            while(cursor.moveToNext()) {
                String Name =  cursor.getString(1);
                String desc =  cursor.getString(2);
                String title =  cursor.getString(4);
                image = cursor.getBlob(3);
                bitmap = BitmapFactory.decodeByteArray(image,0,image.length);

                itemIds.add(new CustomData(Name,title,desc,bitmap));

            }

            cursor.close();

            if (!itemIds.isEmpty()){

//                arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,itemIds);
//                listView.setAdapter(arrayAdapter);
                CustomAdapter Apter = new CustomAdapter(itemIds,this,this);
                recycler.setAdapter(Apter);
                Apter.notifyDataSetChanged();

            }else {

                Toast.makeText(this, "No Record Found ", Toast.LENGTH_SHORT).show();
            }

        }catch (Exception e){

            Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_LONG).show();




        }

    }

    public void  ShowData(String Electri ){

        try {
            MainDatabase dbHelper = new MainDatabase(MainActivity.this);


            SQLiteDatabase db = dbHelper.getReadableDatabase();


            String[] projection = {
                    BaseColumns._ID,
                    ProductTable.ProductEntry.COLUMN_NAME_NAME,
                    ProductTable.ProductEntry.COLUMN_NAME_TITLE,
                    ProductTable.ProductEntry.COLUMN_NAME_IMAGE
            };

        // Filter results WHERE "title" = 'My Title'

            String selection = ProductTable.ProductEntry.COLUMN_NAME_TITLE + " = ?";
            String[] selectionArgs = {Electri};



// How you want the results sorted in the resulting Cursor
            String sortOrder =
                    ProductTable.ProductEntry.COLUMN_NAME_TITLE  + " DESC";

            Cursor cursor = db.query(
                    ProductTable.ProductEntry.TABLE_NAME,   // The table to query
                    projection,             // The array of columns to return (pass null to get all)
                    selection,              // The columns for the WHERE clause
                    selectionArgs,          // The values for the WHERE clause
                    null,                   // don't group the rows
                    null,                   // don't filter by row groups
                    sortOrder               // The sort order
            );

            itemIds = new ArrayList<>();
            while(cursor.moveToNext()) {
                String Name =  cursor.getString(1);
                String desc =  cursor.getString(2);
                String title =  cursor.getString(4);
                image = cursor.getBlob(3);
                bitmap = BitmapFactory.decodeByteArray(image,0,image.length);

                itemIds.add(new CustomData(Name,title,desc,bitmap));

            }

            cursor.close();

            if (!itemIds.isEmpty()){

                CustomAdapter Apter = new CustomAdapter(itemIds,this,this);
                recycler.setAdapter(Apter);
                Apter.notifyDataSetChanged();
            }else {

                Toast.makeText(this, "No Record Found ", Toast.LENGTH_SHORT).show();
            }

        }catch (Exception e){

            Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_LONG).show();




        }

    }

    public void Transistor(View v){
        String Electri  ;
        Electri = "transist";
        ShowData(Electri.toLowerCase());

    }

    public void Resistor(View v){
        String Electri2;
        Electri2 = "resist";
        ShowData(Electri2.toLowerCase());
    }

    public  void Inductor(View v){
        String Electri3;
        Electri3 = "induct";
        ShowData(Electri3.toLowerCase());
    }
    public void Capacitor(View v){
        String Electri4;
        Electri4 = "capacit";
        ShowData(Electri4.toLowerCase());
    }

    public void SearchQuery(){

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterList(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterList(newText);

                return false;
            }
        });

    }

    public void ToListenRecycler(){

    }

    @Override
    public void onitemClick(CustomData customData) {

        Intent intent = new Intent(this , ComponentDetailPage.class);
        String name  = customData.getName();
        intent.putExtra("component",name);
        startActivity(intent);


    }
}