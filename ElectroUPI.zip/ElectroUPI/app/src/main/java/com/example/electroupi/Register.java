package com.example.electroupi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Register extends AppCompatActivity {
   private FirebaseAuth mAuth;
    EditText editTextEmail,editTextPass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        editTextEmail = findViewById(R.id.email);
        editTextPass = findViewById(R.id.password);
    }



    @SuppressLint("NotConstructor")
    public void Register(View v){

        editTextEmail = findViewById(R.id.email);
        editTextPass = findViewById(R.id.password);
        String email = editTextEmail.getText().toString();
        String password = editTextPass.getText().toString();

        if(!email.isEmpty() && !password.isEmpty()){

            FireBaseRegisterClass fireBaseRegisterClass ;
            fireBaseRegisterClass = new FireBaseRegisterClass(this,"Registration failed.","Registration Error."," Registration Successfully","Network Error");
            fireBaseRegisterClass.FirebaseData(email,password);




        }else {


            Toast.makeText(this, "All Field Is Required", Toast.LENGTH_SHORT).show();
        }
    }
    public void login(View view){
        Intent intent = new Intent(Register.this,MainActivity.class);
        startActivity(intent);
        finish();

    }
}