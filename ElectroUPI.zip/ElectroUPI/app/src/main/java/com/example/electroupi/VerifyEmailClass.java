package com.example.electroupi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class VerifyEmailClass extends AppCompatActivity {
    private FirebaseAuth mAuth;
    TextView textViewEmail, textViewVerify;
    EditText editText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_email_class);

        textViewEmail = findViewById(R.id.email);
        textViewVerify = findViewById(R.id.verify);
        editText = findViewById(R.id.passverify);
        Intent intent = getIntent();
         String Email = intent.getStringExtra("email");
        textViewEmail.setText(Email );


//
//        Toast.makeText(this, Email + "Dashboard" + Pass, Toast.LENGTH_SHORT).show();


    }


    public void VerifyMe(View view) {

        String Pass = editText.getText().toString();
         Intent intent = getIntent();
         String Email = intent.getStringExtra("email");
         FireBaseVerifyClass  fireBaseVerifyClass;
         fireBaseVerifyClass= new FireBaseVerifyClass(this,"Authentication failed","Server Error"," Email Sent","Invalide Password");
         fireBaseVerifyClass.FirebaseVerify(Email,Pass);



    }
}