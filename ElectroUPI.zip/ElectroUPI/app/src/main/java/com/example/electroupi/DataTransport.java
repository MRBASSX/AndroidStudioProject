package com.example.electroupi;

import com.google.firebase.auth.FirebaseUser;

public interface DataTransport {



}
