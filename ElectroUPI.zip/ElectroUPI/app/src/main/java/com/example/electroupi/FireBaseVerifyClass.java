package com.example.electroupi;

import static androidx.core.content.ContextCompat.startActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class FireBaseVerifyClass {


    private String A,B,C,D;

    private FirebaseAuth mAuth;

    private Context context ;



    public FireBaseVerifyClass(Context context) {
        this.context = context;

    }


    public FireBaseVerifyClass(Context context,String a, String b, String c, String d) {
        A = a;
        B = b;
        C = c;
        D = d;
        this.context = context;

    }



    protected void FirebaseVerify(String email2, String password2){

        try {
            // Initialize Firebase Auth
            mAuth = FirebaseAuth.getInstance();
//        ArrayList mCustomToken = new ArrayList<>();

            mAuth.signInWithEmailAndPassword(email2,password2)
                    .addOnCompleteListener((Activity) context, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
//                                Log.d(TAG, "signInWithCustomToken:success");
                                FirebaseUser user = mAuth.getCurrentUser();
                                updateUI(user);


                            } else {
                                // If sign in fails, display a message to the user.
                                //
                                Toast.makeText(context, A,Toast.LENGTH_SHORT).show();
                                updateUI(null);
                            }
                        }
                    });

        }catch (Exception e){

            Toast.makeText(context, B, Toast.LENGTH_SHORT).show();

        }
    }


    private void updateUI(FirebaseUser currentUser) {
        try {

            if (!currentUser.getEmail().isEmpty() && !currentUser.isEmailVerified()){

                currentUser.sendEmailVerification();
                Toast.makeText(context,  C, Toast.LENGTH_SHORT).show();
                Toast.makeText(context, "Email Link Sent To " + currentUser.getEmail() , Toast.LENGTH_SHORT).show();

            }
            if (!currentUser.getEmail().isEmpty() && currentUser.isEmailVerified()){

//                Intent intent2 = new Intent(MainActivity.this,EcommerceHome.class);
//                startActivity(context,intent2,null);
                Toast.makeText(context, "Welcome Home", Toast.LENGTH_SHORT).show();

            }

        }catch (Exception e){

            Toast.makeText(context,D, Toast.LENGTH_SHORT).show();
        }





    }
}
