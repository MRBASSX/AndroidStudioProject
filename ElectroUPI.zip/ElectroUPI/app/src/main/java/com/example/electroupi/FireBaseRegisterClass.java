package com.example.electroupi;

import static androidx.core.content.ContextCompat.startActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;



import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class FireBaseRegisterClass {

    private String A,B,C,D;

    private FirebaseAuth mAuth;

    private Context context ;

    public FireBaseRegisterClass(Context context) {
        this.context = context;

    }


    public FireBaseRegisterClass(Context context,String a, String b, String c, String d) {
        A = a;
        B = b;
        C = c;
        D = d;
        this.context = context;
    }

    protected void FirebaseData(String email2,String password2){

        try {
            // Initialize Firebase Auth
            mAuth = FirebaseAuth.getInstance();
//        ArrayList mCustomToken = new ArrayList<>();

            mAuth.createUserWithEmailAndPassword(email2,password2)
                    .addOnCompleteListener((Activity) context, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete( Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
//                                Log.d(TAG, "signInWithCustomToken:success");
                                FirebaseUser user = mAuth.getCurrentUser();
                                updateUI(user);
                            } else {
                                // If sign in fails, display a message to the user.
//                                Log.w(TAG, "signInWithCustomToken:failure", task.getException());
                               Toast.makeText(context, A ,Toast.LENGTH_SHORT).show();
                                updateUI(null);
                            }
                        }
                    });

        }catch (Exception e){

            Toast.makeText(context, B, Toast.LENGTH_SHORT).show();

        }
    }


    private void updateUI(FirebaseUser currentUser) {

        try {

//            Toast.makeText(context, currentUser.getEmail().substring(0,7) + C, Toast.LENGTH_SHORT).show();
            Toast.makeText(context, "Connecting...", Toast.LENGTH_SHORT).show();


            if (!currentUser.getEmail().isEmpty() && !currentUser.isEmailVerified() ){

                Toast.makeText(context, "Please Verify" + C, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(context,VerifyEmailClass.class);
                intent.putExtra("email",currentUser.getEmail());
                startActivity(context,intent,null);




            }
            if (!currentUser.getEmail().isEmpty() && currentUser.isEmailVerified()){

//                Intent intent2 = new Intent(MainActivity.this,EcommerceHome.class);
//                startActivity(context,intent2,null);
                Toast.makeText(context, "Welcome Home", Toast.LENGTH_SHORT).show();

            }


        }catch (Exception e){


            Toast.makeText(context, D, Toast.LENGTH_SHORT).show();
        }


    }
}
