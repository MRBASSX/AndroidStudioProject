package com.example.electroupi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

//import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity  {
  private FirebaseAuth mAuth;
    EditText editTextEmail,editTextPass;
//    FloatingActionButton signing,registering;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       editTextEmail = findViewById(R.id.email);
       editTextPass = findViewById(R.id.password);



//       signing = findViewById(R.id.signin);
//        registering = findViewById(R.id.register);


    }


    public void login(View v){

        editTextEmail = findViewById(R.id.email);
        editTextPass = findViewById(R.id.password);
        String email = editTextEmail.getText().toString();
        String password = editTextPass.getText().toString();


        if(!email.isEmpty() && !password.isEmpty()){
            FireBaseSignInClass  fireBaseClass;
            fireBaseClass= new FireBaseSignInClass(this,"Authentication failed","SignIn Error"," Login Successfully","Network Error");
            fireBaseClass.FirebaseHr(email,password);


        }else {
            Toast.makeText(this, "All Field Is Required", Toast.LENGTH_SHORT).show();

        }
    }

    public void Register(View view){
       Intent intent = new Intent(MainActivity.this,Register.class);
       startActivity(intent);
       finish();

    }


//    public void onStart() {
//        super.onStart();
//        // Check if user is signed in (non-null) and update UI accordingly.
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//        updateUI(currentUser);
//    }


}