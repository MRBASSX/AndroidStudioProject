from django.db.models import Q
from django.shortcuts import render

from .models import Article


# Create your views here.

def home(request):
    Tech = Article.objects.raw("SELECT * FROM article_article WHERE title =  %s ", ["Technology"])
    Scie = Article.objects.raw("SELECT * FROM article_article WHERE title =  %s limit 2", ["Science"])
    Inno = Article.objects.raw("SELECT * FROM article_article WHERE title =  %s limit 2", ["Innovation"])
    return render(request, "article/index.html", {"technology": Tech,"science":Scie,"innovation":Inno})


def show(request, id):
    ArticleDetail = Article.objects.get(id=id)
    return render(request, "article/detail.html", {"key": ArticleDetail})


def showAll(request):
    article = Article.objects.all()

    if request.method == "POST":
        if request.POST['search']:
          data = request.POST['search']
          # article = Article.objects.filter(Q(subtitle__icontains = data)| Q(title__icontains = 'Artificial'))
          article = Article.objects.filter(Q(subtitle__icontains=data))
          return render(request, "article/showAll.html", {"ALL": article})


    return render(request, "article/showAll.html", {"ALL": article})
