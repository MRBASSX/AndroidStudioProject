package com.example.whatsap;

public class MyModel {

    private String name ;
    private Double price;
    private Double quantity;
    private  int profile;

    public MyModel(String name, Double price, Double quantity, int profile) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.profile = profile;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public int getProfile() {
        return profile;
    }

    public void setProfile(int profile) {
        this.profile = profile;
    }
}
