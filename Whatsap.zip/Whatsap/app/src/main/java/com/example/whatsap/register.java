package com.example.whatsap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class register extends AppCompatActivity {

    EditText username, email, password ,confirm_password;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username = findViewById(R.id.username);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirm_password = findViewById(R.id.comfirm_password);








    }


    public void Register(View V){

        String Confirm_password  = confirm_password.getText().toString();
        String Username  = username.getText().toString();
        String Email  = email.getText().toString();
        String Password  = password.getText().toString();

        if(Username.isEmpty() || Email.isEmpty() || Password.isEmpty() || Confirm_password.isEmpty()){


              Toast.makeText(this, "All Field Is Required", Toast.LENGTH_SHORT).show();

        }else{

             if(!(Email.contains("@") && Email.endsWith(".com")) || !(Email.contains("@") && Email.endsWith(".gh"))){

                 Toast.makeText(this, "Please Enter A valid Email Address", Toast.LENGTH_SHORT).show();
             } else if (!Password.equals(Confirm_password)) {

                 Toast.makeText(this, "Password don't match", Toast.LENGTH_SHORT).show();
             }else{

                 Toast.makeText(register.this, "Successfully Registered", Toast.LENGTH_SHORT).show();
                 Intent login = new Intent(register.this,login.class);
                 startActivity(login);

             }
        }


    }

    public void Login(View V){
        Toast.makeText(this, "Login is Clicked", Toast.LENGTH_SHORT).show();
        Intent login = new Intent(register.this,login.class);
        startActivity(login);
    }
}