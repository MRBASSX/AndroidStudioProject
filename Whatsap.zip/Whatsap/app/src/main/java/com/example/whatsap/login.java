package com.example.whatsap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class login extends AppCompatActivity {

    EditText username, password ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);





    }



    public void Register(View V){
        Intent Register = new Intent(login.this,register.class);
        startActivity(Register);
    }

    public void Login(View V){


        String Username[] = {"Africa","America","Asia","Europe"} ;

        ArrayList arrayList =  new ArrayList<MyModel>();
        arrayList.add(new MyModel("ABA",12.5,2.67,333333333));
//        arrayList.add("America");
//        arrayList.add("Asia");
//        arrayList.add("Europe");



        Intent home = new Intent(login.this,home.class);
        home.putExtra("key", arrayList);
        startActivity(home);

    }

}