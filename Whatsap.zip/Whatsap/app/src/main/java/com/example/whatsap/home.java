package com.example.whatsap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class home extends AppCompatActivity {

     TextView name ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        name = findViewById(R.id.Name);
        Intent intent = getIntent();
        ArrayList data =  intent.getStringArrayListExtra("key");

//        name.setText(data);



    }

    public  void Logout(View V){
        Intent login = new Intent(home.this, login.class);
        startActivity(login);

    }



}