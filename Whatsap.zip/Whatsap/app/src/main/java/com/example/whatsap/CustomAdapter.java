package com.example.whatsap;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter  extends ArrayAdapter<CustomModel> {
    Context Rcontext;
    int Rresource;


    LayoutInflater layoutInflater;




    public CustomAdapter(@NonNull Context context, int resource, @NonNull ArrayList<CustomModel> objects) {
        super(context, resource, objects);
        this.Rcontext = context;
        this.Rresource = resource;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        layoutInflater  = LayoutInflater.from(Rcontext);

        convertView  = layoutInflater.inflate(Rresource,parent,false);

        ImageView  image =  convertView.findViewById(R.id.CustomImage);
        image.setImageResource(getItem(position).getImage());

        TextView name =  convertView.findViewById(R.id.CustomName);
        name.setText(getItem(position).getName());

        TextView  price =  convertView.findViewById(R.id.CustomPrice);
        price.setText(String.valueOf(getItem(position).getPrice()));


        return convertView;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }
}
