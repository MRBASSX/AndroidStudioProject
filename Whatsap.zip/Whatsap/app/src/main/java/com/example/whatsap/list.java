package com.example.whatsap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class list extends AppCompatActivity {



//     ArrayAdapter arrayAdapter;
     ListView listView;
     CustomAdapter customAdapter;
     ArrayList<CustomModel> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        listView  = findViewById(R.id.list_view);
        arrayList = new ArrayList<CustomModel>();

        arrayList.add(new CustomModel(R.drawable.user,"apple",5000));
        arrayList.add(new CustomModel(R.drawable.user,"apple",5000));
        arrayList.add(new CustomModel(R.drawable.user,"apple",5000));

        customAdapter = new CustomAdapter(this ,R.layout.custom_layout, arrayList);

        listView.setAdapter(customAdapter);
    }
}